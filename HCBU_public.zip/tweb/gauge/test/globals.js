window.ns = window;
